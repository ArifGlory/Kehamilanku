package myproject.kehamilanku.Kelas;

public class SharedVariable {
    public static String nama = "";
    public static String userID = "";
    public static String foto = "";
    public static String email = "";
    public static String phone = "";
    public static String alamat = "";
    public static String keyword = "";
    public static String adminMail = "admin@gmail.com";
    public static long maxHarga = 0;

}
